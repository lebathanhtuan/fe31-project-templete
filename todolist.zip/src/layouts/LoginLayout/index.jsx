import * as S from "./styles";

function LoginLayout() {
  return <S.LoginWrapper>Login</S.LoginWrapper>;
}

export default LoginLayout;
