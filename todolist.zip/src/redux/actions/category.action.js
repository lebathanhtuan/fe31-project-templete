import { createAction } from "@reduxjs/toolkit";

export const getCategoryListAction = createAction("GET_CATEGORY_LIST");
