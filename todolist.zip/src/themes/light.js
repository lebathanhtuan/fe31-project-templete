export const light = {
  footer: "#5f9ea0",
};
