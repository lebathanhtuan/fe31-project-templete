export const dark = {
  footer: "#2e6769",
};
