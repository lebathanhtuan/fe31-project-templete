import { createAction } from "@reduxjs/toolkit";

export const changeThemeAction = createAction("CHANGE_THEME");
